import { useEffect, useState } from 'react';
import { Activity, Smartphone, Users, Route } from 'lucide-react';
import apiClient from '../api/client';

interface AdminStats {
  totalUsers: number;
  totalDevices: number;
  onlineDevices: number;
  recordedTracks: number;
}

const cards = [
  { key: 'totalUsers', label: 'អ្នកប្រើប្រាស់សរុប', icon: Users, color: 'bg-blue-500' },
  { key: 'totalDevices', label: 'ឧបករណ៍បានចុះឈ្មោះ', icon: Smartphone, color: 'bg-green-500' },
  { key: 'onlineDevices', label: 'ឧបករណ៍បានឃើញក្នុង ៥ នាទីចុងក្រោយ', icon: Activity, color: 'bg-primary-500' },
  { key: 'recordedTracks', label: 'ផ្លូវដែលបានកត់ត្រា', icon: Route, color: 'bg-orange-500' },
] as const;

export default function Dashboard() {
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [error, setError] = useState('');

  useEffect(() => {
    let cancelled = false;
    apiClient
      .get<{ data: AdminStats }>('/admin/stats')
      .then((response) => {
        if (!cancelled) setStats(response.data.data);
      })
      .catch((requestError: any) => {
        if (!cancelled) {
          setError(
            requestError.response?.data?.message ||
              'មិនអាចទាញយកស្ថិតិពិតពី server បានទេ',
          );
        }
      });

    return () => {
      cancelled = true;
    };
  }, []);

  return (
    <div className="space-y-6">
      {error && (
        <p role="alert" className="rounded-lg bg-red-50 p-4 text-sm text-red-700">
          {error}
        </p>
      )}
      <div className="grid grid-cols-1 gap-6 md:grid-cols-2 xl:grid-cols-4">
        {cards.map(({ key, label, icon: Icon, color }) => (
          <section key={key} className="rounded-lg bg-white p-6 shadow dark:bg-gray-800">
            <div className="flex items-center justify-between gap-3">
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400 khmer-font">{label}</p>
                <p className="mt-2 text-3xl font-bold text-gray-900 dark:text-white">
                  {stats ? stats[key].toLocaleString() : '—'}
                </p>
              </div>
              <div className={`${color} rounded-lg p-3`}>
                <Icon className="h-8 w-8 text-white" />
              </div>
            </div>
          </section>
        ))}
      </div>
      <p className="text-sm text-gray-500 dark:text-gray-400 khmer-font">
        ស្ថិតិទាំងនេះទាញពី database ពិត។ ឧបករណ៍ត្រូវផ្ញើទីតាំងមក server ទើបអាចឃើញលើផែនទី និងកំណត់ហេតុ។
      </p>
    </div>
  );
}
